#include"Compute.h"

CCompute::CCompute()
{
	splitWidth = 32;
}

CCompute::~CCompute()
{
	//delete m_grayShow;
}


void CCompute::OpenImage( CString& FilePathName )
{
	//m_grayShow=new CGrayShow();
	m_grayShow.loadImage(FilePathName);
}

void CCompute::getAllFiles( string path, vector<string>& files)
{
	//�ļ����  
    long   hFile   =   0; 
	//�ļ���Ϣ  
    struct _finddata_t fileinfo;
	string p;  
    if((hFile = _findfirst(p.assign(path).append("\\*").c_str(),&fileinfo)) !=  -1)
	{
		do
		{
			if(fileinfo.attrib &  _A_SUBDIR)	//�ж��Ƿ����ļ���
			{
				if(strcmp(fileinfo.name,".") != 0  &&  strcmp(fileinfo.name,"..") != 0) 
				{
					files.push_back(p.assign(path).append("\\").append(fileinfo.name) );
					getAllFiles( p.assign(path).append("\\").append(fileinfo.name), files ); 
				}
			}
			else
				files.push_back(p.assign(path).append("\\").append(fileinfo.name) ); 

		}while(_findnext(hFile, &fileinfo)  == 0);
	}
}



vector<double> CCompute::ComputeFeature()
{
	double dEnergy1			   = 0.0;
	double dEntropy1		   = 0.0;
	double dInertiaQuadrature1 = 0.0;
	double dLocalCalm1		   = 0.0;
	double dCorrelation1	   = 0.0;

	double dEnergy2			   = 0.0;
	double dEntropy2		   = 0.0;
	double dInertiaQuadrature2 = 0.0;
	double dLocalCalm2		   = 0.0;
	double dCorrelation2	   = 0.0;

	double dEnergy3			   = 0.0;
	double dEntropy3		   = 0.0;
	double dInertiaQuadrature3 = 0.0;
	double dLocalCalm3		   = 0.0;
	double dCorrelation3	   = 0.0;

	double dEnergy4			   = 0.0;
	double dEntropy4		   = 0.0;
	double dInertiaQuadrature4 = 0.0;
	double dLocalCalm4		   = 0.0;
	double dCorrelation4	   = 0.0;

	/*
	double dEnergyH			   = 0.0;
	double dEntropyH		   = 0.0;
	double dInertiaQuadratureH = 0.0;
	double dLocalCalmH		   = 0.0;
	double dCorrelationH	   = 0.0;

	//����3�����������������ԭʼ����ֻ������һ�������
	double dEnergyLD		   = 0.0;
	double dEntropyLD		   = 0.0;
	double dInertiaQuadratureLD= 0.0;
	double dLocalCalmLD		   = 0.0;
	double dCorrelationLD	   = 0.0;

	double dEnergyRD		   = 0.0;
	double dEntropyRD		   = 0.0;
	double dInertiaQuadratureRD= 0.0;
	double dLocalCalmRD		   = 0.0;
	double dCorrelationRD	   = 0.0;

	double dEnergyV			   = 0.0;
	double dEntropyV		   = 0.0;
	double dInertiaQuadratureV = 0.0;
	double dLocalCalmV		   = 0.0;
	double dCorrelationV	   = 0.0;
	*/
	vector<double> Feature;		//����ȡ��������vector��ʽ����

	//0��--> PMatrixH
	//�ָ�ͼƬ
	//BYTE** srcImgAry = m_grayShow.getImageArray();
	int    srcWth    = m_grayShow.getImageWidth();
	int    srcHgt    = m_grayShow.getImageHeight();
	vector<BYTE**> splitResult = m_grayShow.split(m_grayShow.ImageArray, srcWth, srcHgt, splitWidth);

	//�ͷŴ��ԭʼ���ݵĶ�̬����ռ�
	for(int i=0;i<m_grayShow.m_lHeight;++i)
		delete []m_grayShow.ImageArray[i];
	delete []m_grayShow.ImageArray;
	m_grayShow.ImageArray = NULL;

	vector<BYTE**>::iterator it = splitResult.begin();
	//����ÿһ���ָ���������
	//int** srcPMatrixH = NULL;
	for(;it!=splitResult.end();++it)
	{
		//srcPMatrixH = m_grayShow.PMatrixH;
		m_grayShow.ComputeMatrix(*it,splitWidth,splitWidth);
		//0��-->PMatrixH
		m_grayShow.ComputeFeature(dEnergy1, dEntropy1, dInertiaQuadrature1, dCorrelation1, dLocalCalm1,  m_grayShow.PMatrixH, m_grayShow.GrayLayerNum);//m_grayShow.GrayLayerNum);
		

		/*
		dEnergyH              += dEnergy1;
		dEntropyH             += dEntropy1;
		dInertiaQuadratureH   += dInertiaQuadrature1;
		dCorrelationH         += dCorrelation1;
		dLocalCalmH           += dLocalCalm1;
		//��ֵ�����ݳ�Ա
		m_dEnergy1			  =  dEnergyH;
		m_dEntropy1			  =  dEntropyH;
		m_dInertiaQuadrature1 =  dInertiaQuadratureH;
		m_dCorrelation1		  =  dCorrelationH;
		m_dLocalCalm1		  =  dLocalCalmH;
		*/
		//����ȡ��������vector��ʽ����
		Feature.push_back(dEnergy1);
		Feature.push_back(dEntropy1);
		Feature.push_back(dInertiaQuadrature1);
		Feature.push_back(dLocalCalm1);
		Feature.push_back(dCorrelation1);

		//����
		dEnergy1				= 0.0;
		dEntropy1				= 0.0;
		dInertiaQuadrature1		= 0.0;
		dLocalCalm1				= 0.0;
		dCorrelation1			= 0.0;

//#ifdef _ALLDIRECTION
		//45��-->PMatrixRD
		m_grayShow.ComputeFeature(dEnergy2, dEntropy2, dInertiaQuadrature2, dCorrelation2, dLocalCalm2, m_grayShow.PMatrixRD,m_grayShow.GrayLayerNum);// m_grayShow.GrayLayerNum);
		Feature.push_back(dEnergy2);
		Feature.push_back(dEntropy2);
		Feature.push_back(dInertiaQuadrature2);
		Feature.push_back(dLocalCalm2);
		Feature.push_back(dCorrelation2);

		//90��-->PMatrixV
		m_grayShow.ComputeFeature(dEnergy3, dEntropy3, dInertiaQuadrature3, dCorrelation3, dLocalCalm3, m_grayShow.PMatrixV,m_grayShow.GrayLayerNum);
		Feature.push_back(dEnergy3);
		Feature.push_back(dEntropy3);
		Feature.push_back(dInertiaQuadrature3);
		Feature.push_back(dLocalCalm3);
		Feature.push_back(dCorrelation3);

		//135��-->PMatrixLD
		m_grayShow.ComputeFeature(dEnergy4, dEntropy4, dInertiaQuadrature4, dCorrelation4, dLocalCalm4, m_grayShow.PMatrixLD,m_grayShow.GrayLayerNum);
		Feature.push_back(dEnergy4);
		Feature.push_back(dEntropy4);
		Feature.push_back(dInertiaQuadrature4);
		Feature.push_back(dLocalCalm4);
		Feature.push_back(dCorrelation4);

		//����
		//dEnergy1					= 0.0;
		//dEntropy1					= 0.0;
		//dInertiaQuadrature1		= 0.0;
		//dLocalCalm1				= 0.0;
		//dCorrelation1				= 0.0;

		dEnergy2				= 0.0;
		dEntropy2				= 0.0;
		dInertiaQuadrature2		= 0.0;
		dLocalCalm2				= 0.0;
		dCorrelation2			= 0.0;

		dEnergy3				= 0.0;
		dEntropy3				= 0.0;
		dInertiaQuadrature3		= 0.0;
		dLocalCalm3				= 0.0;
		dCorrelation3			= 0.0;

		dEnergy4				= 0.0;
		dEntropy4				= 0.0;
		dInertiaQuadrature4		= 0.0;
		dLocalCalm4				= 0.0;
		dCorrelation4			= 0.0;


		//�ͷ�PMatrixH��̬������ڴ�
		for(int i=0;i<m_grayShow.GrayLayerNum;++i)
			delete [] m_grayShow.PMatrixH[i];
		delete [] m_grayShow.PMatrixH;
		 m_grayShow.PMatrixH = NULL;

		for(int i=0;i<m_grayShow.GrayLayerNum;++i)
			delete []m_grayShow.PMatrixRD[i];
		delete []m_grayShow.PMatrixRD;
		m_grayShow.PMatrixRD = NULL;

		for(int i=0;i<m_grayShow.GrayLayerNum;++i)
			delete []m_grayShow.PMatrixV[i];
		delete []m_grayShow.PMatrixV;
		m_grayShow.PMatrixV = NULL;

		for(int i=0;i<m_grayShow.GrayLayerNum;++i)
			delete []m_grayShow.PMatrixLD[i];
		delete []m_grayShow.PMatrixLD;
		m_grayShow.PMatrixLD = NULL;

//#endif
	}
	//delete m_pgrayShow;

	/*
	//0��-->PMatrixH
	m_grayShow.ComputeMatrix(m_grayShow.ImageArray, m_grayShow.ImageWidth, m_grayShow.ImageHeight);
	m_grayShow.ComputeFeature(dEnergy1, dEntropy1, dInertiaQuadrature1, dCorrelation1, dLocalCalm1, m_grayShow.PMatrixH, m_grayShow.GrayLayerNum);
	dEnergyH              += dEnergy1;
	dEntropyH             += dEntropy1;
	dInertiaQuadratureH   += dInertiaQuadrature1;
	dCorrelationH         += dCorrelation1;
	dLocalCalmH           += dLocalCalm1;
	//��ֵ�����ݳ�Ա
	m_dEnergy1			  =  dEnergyH;
	m_dEntropy1			  =  dEntropyH;
	m_dInertiaQuadrature1 =  dInertiaQuadratureH;
	m_dCorrelation1		  =  dCorrelationH;
	m_dLocalCalm1		  =  dLocalCalmH;
	//����ȡ��������vector��ʽ����
	vector<double> Feature;
	Feature.push_back(m_dEnergy1);
	Feature.push_back(m_dEntropy1);
	Feature.push_back(m_dInertiaQuadrature1);
	Feature.push_back(m_dLocalCalm1);
	Feature.push_back(m_dCorrelation1);

	
	//45��-->PMatrixRD
	m_grayShow.ComputeFeature(dEnergy2, dEntropy2, dInertiaQuadrature2, dCorrelation2, dLocalCalm2, m_grayShow.PMatrixRD, m_grayShow.GrayLayerNum);
	dEnergyRD              += dEnergy2;
	dEntropyRD             += dEntropy2;
	dInertiaQuadratureRD   += dInertiaQuadrature2;
	dCorrelationRD         += dCorrelation2;
	dLocalCalmRD           += dLocalCalm2;

	m_dEnergy2			  =  dEnergyRD;
	m_dEntropy2			  =  dEntropyRD;
	m_dInertiaQuadrature2 =  dInertiaQuadratureRD;
	m_dCorrelation2		  =  dCorrelationRD;
	m_dLocalCalm2		  =  dLocalCalmRD;

	Feature.push_back(m_dEnergy2);
	Feature.push_back(m_dEntropy2);
	Feature.push_back(m_dInertiaQuadrature2);
	Feature.push_back(m_dLocalCalm2);
	Feature.push_back(m_dCorrelation2);



	//90��-->PMatrixV
	m_grayShow.ComputeFeature(dEnergy3, dEntropy3, dInertiaQuadrature3, dCorrelation3, dLocalCalm3, m_grayShow.PMatrixV, m_grayShow.GrayLayerNum);
	dEnergyV              += dEnergy3;
	dEntropyV             += dEntropy3;
	dInertiaQuadratureV   += dInertiaQuadrature3;
	dCorrelationV         += dCorrelation3;
	dLocalCalmV           += dLocalCalm3;

	m_dEnergy3			  =  dEnergyV;
	m_dEntropy3			  =  dEntropyV;
	m_dInertiaQuadrature3  =  dInertiaQuadratureV;
	m_dCorrelation3		  =  dCorrelationV;
	m_dLocalCalm3		  =  dLocalCalmV;

	Feature.push_back(m_dEnergy3);
	Feature.push_back(m_dEntropy3);
	Feature.push_back(m_dInertiaQuadrature3);
	Feature.push_back(m_dLocalCalm3);
	Feature.push_back(m_dCorrelation3);	



	//135��-->PMatrixLD
	m_grayShow.ComputeFeature(dEnergy4, dEntropy4, dInertiaQuadrature4, dCorrelation4, dLocalCalm4, m_grayShow.PMatrixLD, m_grayShow.GrayLayerNum);
	dEnergyLD              += dEnergy4;
	dEntropyLD             += dEntropy4;
	dInertiaQuadratureLD   += dInertiaQuadrature4;
	dCorrelationLD         += dCorrelation4;
	dLocalCalmLD           += dLocalCalm4;

	m_dEnergy4			  =  dEnergyLD;
	m_dEntropy4			  =  dEntropyLD;
	m_dInertiaQuadrature4  =  dInertiaQuadratureLD;
	m_dCorrelation4		  =  dCorrelationLD;
	m_dLocalCalm4		  =  dLocalCalmLD;

	Feature.push_back(m_dEnergy4);
	Feature.push_back(m_dEntropy4);
	Feature.push_back(m_dInertiaQuadrature4);
	Feature.push_back(m_dLocalCalm4);
	Feature.push_back(m_dCorrelation4);	
	*/



	vector<BYTE**>::iterator it_del = splitResult.begin();
	for(;it_del!=splitResult.end();++it_del)
	{
		for(int i=0;i<splitWidth;++i)
			delete [](*it_del)[i];
		delete [](*it_del);
		*it_del = NULL;
	}
			
	return Feature;
}